package org.Day2.Ex2.java.MyPackage;

public class PaymentBeanImpl implements PaymentBean {
private int cno;
private String cname;
private UIPayment UIP;
private WalletPayment WP;
	public UIPayment getUIP() {
	return UIP;
}
public void setUIP(UIPayment uIP) {
	UIP = uIP;
}
public WalletPayment getWP() {
	return WP;
}
public void setWP(WalletPayment wP) {
	WP = wP;
}
	public PaymentBeanImpl(int cno, String cname) {
	super();
	this.cno = cno;
	this.cname = cname;
}
	public void display() {
		// TODO Auto-generated method stub
System.out.println("cno = "+cno+" cname = "+cname);
	UIP.display_UIP();
	WP.display_WP();
	}

}
