package org.Day2.Ex2.java.MyPackage;

public class WalletPayment {
public void display_WP()
{
	System.out.println("In Wallet Payment.....");
}
}
