package org.Day2.Ex2.java.MyPackage;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		PaymentBean pay=(PaymentBean) context.getBean("PayBean");
		pay.display();
	}

}
