package org.Day2.Ex2.java.MyPackage;

public interface PaymentBean {
public void display();
}
