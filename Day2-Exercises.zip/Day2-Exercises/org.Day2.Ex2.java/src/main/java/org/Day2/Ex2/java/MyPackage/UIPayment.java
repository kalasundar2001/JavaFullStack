package org.Day2.Ex2.java.MyPackage;

public class UIPayment {
public void display_UIP()
{
	System.out.println("In UIPayment....");
}
}
