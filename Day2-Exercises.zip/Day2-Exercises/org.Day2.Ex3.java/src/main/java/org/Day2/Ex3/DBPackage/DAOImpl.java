package org.Day2.Ex3.DBPackage;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.Day2.Ex3.java.MyPackage.CustomerClass;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class DAOImpl implements DAOInterface {
private DataSource dsn;
	public DataSource getDsn() {
	return dsn;
}
public void setDsn(DataSource dsn) {
	this.dsn = dsn;
}
	public void insert(CustomerClass cust) {
		// TODO Auto-generated method stub
		String sql="insert into customer values (?, ?, ?)";
		Connection conn=null;
		try {
			conn= (Connection)dsn.getConnection();
			PreparedStatement ps = (PreparedStatement)conn.prepareStatement(sql);
			ps.setInt(1, cust.getCustno());
			ps.setString(2, cust.getCustname());
			ps.setInt(3, cust.getCustage());
			ps.executeUpdate();
			System.out.println("Records inserted successfully");
		}
		catch(SQLException e)
		{

			throw new RuntimeException(e);
			
			
		}
		finally
		{
			if(conn!=null)
				try {
					System.out.println("Before");

					conn.close();
				}
			catch(SQLException e) {}
		}
		//return false;

	}	
}