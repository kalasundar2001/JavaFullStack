package org.Day2.Ex3.java.MyPackage;

public class CustomerClass {
private int custno,custage;
private String custname;
public int getCustno() {
	return custno;
}
public void setCustno(int custno) {
	this.custno = custno;
}
public int getCustage() {
	return custage;
}
public void setCustage(int custage) {
	this.custage = custage;
}
public String getCustname() {
	return custname;
}
public void setCustname(String custname) {
	this.custname = custname;
}

}
