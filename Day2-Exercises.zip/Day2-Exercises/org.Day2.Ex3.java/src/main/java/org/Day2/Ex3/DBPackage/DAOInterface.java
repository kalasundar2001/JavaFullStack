package org.Day2.Ex3.DBPackage;

import org.Day2.Ex3.java.MyPackage.CustomerClass;

public interface DAOInterface {
public void insert(CustomerClass cust);
}
