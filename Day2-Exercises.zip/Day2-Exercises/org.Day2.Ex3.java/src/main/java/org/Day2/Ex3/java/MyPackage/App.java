package org.Day2.Ex3.java.MyPackage;

import org.Day2.Ex3.DBPackage.DAOImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
DAOImpl dao = (DAOImpl) context.getBean("customerdao");
CustomerClass cc = new CustomerClass();
cc.setCustno(100);
cc.setCustname("kamala");
cc.setCustage(40);
dao.insert(cc);
/*if(b)
	System.out.println("Record successfully inserted....");
else
	System.out.println("Sorry... Technical error");
	}

}*/
	}
}
