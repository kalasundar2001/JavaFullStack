package org.Day2.Ex1.MyPackage;

public interface CustomerIntf {
public void displayMessage();
}
