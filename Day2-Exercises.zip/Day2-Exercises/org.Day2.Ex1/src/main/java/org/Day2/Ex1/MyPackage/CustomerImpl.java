package org.Day2.Ex1.MyPackage;

public class CustomerImpl implements CustomerIntf {
private int c_id;
private String c_name;
private int age;
	
	public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
	public CustomerImpl(int c_id, String c_name) {
	super();
	this.c_id = c_id;
	this.c_name = c_name;
}
public void cust_init()
{
	System.out.println("Calling cust_init()");
	}
public void cust_destroy() {
	System.out.println("Calling cust_destroy()");
	
}
	public void displayMessage() {
		// TODO Auto-generated method stub
System.out.println("Customer id, name and age is "+c_id+" "+c_name+" "+age);
	}

}
